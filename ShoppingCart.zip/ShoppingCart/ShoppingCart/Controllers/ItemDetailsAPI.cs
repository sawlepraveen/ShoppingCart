﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShoppingDataAccess;
namespace ShoppingCart.Controllers
{   [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ItemDetailsAPI : ControllerBase
    {
        private readonly AppDbContext _appDbContext;
        public ItemDetailsAPI(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        [HttpGet]
        [Route("Details")]
        public IEnumerable<ItemDetails> GetItemDetails()
        {
            return _appDbContext.ItemDetails.ToList();
        }

        [HttpGet]
        [Route("Details/{ItemName}")]
        public IEnumerable<ItemDetails> GetItemDetails(string ItemName)
        {
            return _appDbContext.ItemDetails.Where(item=>item.Item_Name==ItemName).ToList();
        }
        
    }
}
